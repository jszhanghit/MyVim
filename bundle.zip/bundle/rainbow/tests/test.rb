{{{}}}
((()))
[[[]]]
[[[[]]]]

def sample_function(a, b)
    ((()))
    [[[]]]
end

class SampleClass
    def sample_method(a, b)
        [[[]]]
    end
end
